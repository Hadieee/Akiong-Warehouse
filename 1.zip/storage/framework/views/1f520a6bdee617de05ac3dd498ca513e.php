<?php $__env->startSection('title'); ?>
    Data Pemasok - Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="sm:ml-64">
        <div class="flex flex-col h-screen px-6 py-8  items-center bg-gray-700">
            <p class="text-4xl font-bold mb-10 mx-5 text-white">Data Pemasok</p>
            <div class="h-full w-full m-4 p-8 bg-white rounded-lg drop-shadow-md">
                <div class="flex flex-col items-center rounded w-full bg-white">
                    <div class="w-full h-auto flex items-center justify-between mb-2">
                        <form action="<?php echo e(route('admin.searchpemasokadmin')); ?>" method="get" class="flex items-center">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="search" placeholder="Cari Nama Pemasok"
                                class="px-2 py-1 text-lg border rounded-md">
                            <button type="submit"
                                class="bg-blue-500 text-white px-4 py-2 rounded-md ml-2 hover:bg-blue-600">
                                <i class="fas fa-search"></i> Cari
                            </button>
                        </form>
                    </div>
                    <table class="w-full text-sm text-center mt-2">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-100">
                            <tr>
                                <th class="py-2 px-4 border-b">ID</th>
                                <th class="py-2 px-4 border-b">ID Pemasok</th>
                                <th class="py-2 px-4 border-b">Nama Pemasok</th>
                                <th class="py-2 px-4 border-b">Jumlah Barang Pemasok</th>
                                <th class="py-2 px-4 border-b">Nomor Telepon</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pemasok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="py-2 px-4 border-b"><?php echo e(++$index); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($item->id_pemasok); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($item->nama_pemasok); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($item->total_barang); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($item->no_telepon); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kuliah\SMST5\Framework\Akiong-Warehouse\resources\views/admin/pemasok.blade.php ENDPATH**/ ?>