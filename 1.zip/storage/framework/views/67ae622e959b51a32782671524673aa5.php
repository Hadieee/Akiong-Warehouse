<?php $__env->startSection('title'); ?>
    Data Barang - Manager
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class=" sm:ml-64">
        <div class="flex flex-col h-screen px-6 py-8 items-center bg-gray-700 ">
            <p class="text-4xl font-bold mb-10 mx-5 text-white">Data Barang</p>

            <?php if(session('error')): ?>
                <div class="w-full mb-4">
                    <div class="p-2 rounded-sm bg-red-100 ring-1 ring-red-500">
                        <p class="text-red-500">
                            <?php echo e(session('error')); ?>

                        </p>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="w-full mb-4">
                    <div class="p-2 rounded-sm bg-green-100 ring-1 ring-green-500 flex">
                        <p class="text-green-500">
                            <?php echo e(session('success')); ?>

                        </p>
                    </div>
                </div>
            <?php endif; ?>

            <div class="h-full w-full m-4 p-8 bg-white rounded-lg drop-shadow-md overflow-auto">
                <div class="flex flex-col items-center rounded w-full bg-white">
                    <div class="w-full h-auto flex items-center justify-between mb-4">
                        <form action="<?php echo e(route('manager.searchbarangmanager')); ?>" method="post" class="flex items-center">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="search" placeholder="Cari Nama Barang"
                                class="px-2 py-1 text-lg border rounded-md">
                            <button type="submit"
                                class="bg-blue-500 text-white px-4 py-2 rounded-md ml-2 hover:bg-blue-600">
                                <i class="fas fa-search"></i> Cari
                            </button>
                        </form>
                        <a href="<?php echo e(route('manager.downloadDataBarang')); ?>"
                            class="bg-green-600 text-white px-4 py-2 rounded-md flex items-center hover:bg-green-700">
                            <i class="fas fa-print mr-2"></i> Print
                        </a>
                    </div>
                    <table class="w-full text-sm text-center">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-100">
                            <tr>
                                <th class="py-2 px-4 border-b">No</th>
                                <th class="py-2 px-4 border-b">ID Barang</th>
                                <th class="py-2 px-4 border-b">Kategori Barang</th>
                                <th class="py-2 px-4 border-b">Pemasok Barang</th>
                                <th class="py-2 px-4 border-b">Nama Barang</th>
                                <th class="py-2 px-4 border-b">Stok Barang</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=1 ?>
                            <?php $__currentLoopData = $barang['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="py-2 px-4 border-b"><?php echo e($i++); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($item['id_barang']); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($item['kategori']['nama_kategori']); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($item['pemasok']['nama_pemasok']); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($item['nama_barang']); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($item['stok_barang']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kuliah\SMST5\Framework\Akiong-Warehouse\resources\views/manager/barang.blade.php ENDPATH**/ ?>