@extends('layouts.global')
@section('content')

@include('components.navbar')
@include('components.hero')
@include('components.aboutus')
@include('components.benefit')
@include('components.fiture')
@include('components.testimonial')
@include('components.footer')


@endsection
